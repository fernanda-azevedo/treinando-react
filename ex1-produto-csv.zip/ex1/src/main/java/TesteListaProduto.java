import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class TesteListaProduto {

     public static void gravaArquivoCsv(ListaObj<Produto> produto, String nomeArq){
            FileWriter arq = null;   // Objeto que representa o arquivo a ser gravado
            Formatter saida = null; // Objeto que usaremos para escrever no arquivo
            Boolean deuRuim = false;
            nomeArq += ".csv"; // Acresenta a extensão .csv ao nome do arquivo

          // Bloco try-catch para abrir o arquivo

            try{
                arq = new FileWriter(nomeArq, false); // Abre o arquivo nomeArq
                saida = new Formatter(arq); // Associa o objeto saida do arquivo
            }
           catch (IOException erro){
                System.out.println("Erro ao abrir o arquivo");
                System.exit(1);
            }

          // Bloco try-catch para percorrer a lista e gravar no arquivo
           try {
                for (int i = 0; i < produto.getTamanho(); i++) {
                   Produto produto1 = produto.getElemento(i);
                    saida.format("%d;%s;%.2f;%s;%d\n",produto1.getCodProduto(), produto1.getNome(),
                            produto1.getPreco(), produto1.getAvaliacao(), produto1.getQuantidadeVendida());
               }
            }
            catch (FormatterClosedException erro){
               System.out.println("Erro ao gravar no arquivo");
                deuRuim = true;

            }
            finally {
                saida.close();
                try {
                    arq.close();
                }
                catch (IOException erro){
                   System.out.println("Erro ao fechar o arquivo");
                    deuRuim = true;
                }
                if (deuRuim){
                    System.exit(1);
                }
            }
        }

       public static void leExibeArquivoCsv(String nomeArq) {
            FileReader arq = null; // Objeto que representa o arquivo para leitura
            Scanner entrada = null; // Objeto usado para ler o arquivo
            Boolean deuRuim = false;
            nomeArq += ".csv";

            //Bloco try-catch para abrir o arquivo
           try {
                arq = new FileReader(nomeArq);
                // Cria o objeto do Scanner, informando que o delimitador é o ';' ou o \n
                entrada = new Scanner(arq).useDelimiter(";|\\n");
           }
            catch(FileNotFoundException erro){
                System.out.println("Arquivo não encontrado");
                System.exit(1);
      }

            //Bloco try-catch para ler o arquivo
            try {
                System.out.printf("%6s %-14s %7s %7s %8s\n", "CODIGO", "NOME", "PREÇO", "NOTA", "VENDIDOS");
                while (entrada.hasNext()){ // enquanto não for final do arquivo
                    Integer codProduto = entrada.nextInt();
                    String nome = entrada.next();
                    Double preco = entrada.nextDouble();
                    String avaliacao = entrada.next();
                    Integer quantidadeVendida = entrada.nextInt();
                    System.out.printf("%6d %-14s %.2f %7S %14d\n", codProduto, nome, preco, avaliacao, quantidadeVendida);
                }
           }
            catch (NoSuchElementException erro){
               System.out.println("Arquivo com problemas");
                deuRuim = true;
            }
            catch (IllegalStateException erro){
                System.out.printf("Erro na leitura do arquivo");
                deuRuim = true;
            }
            finally {
                entrada.close();
                try {
                    arq.close();
                }
                catch (IOException erro){
                    System.out.println("Erro ao fechar o arquivo");
                    deuRuim = true;
                }
                if (deuRuim){
                    System.exit(1);
                }
            }

        }

    public static void main(String[] args) {

         ListaObj<Produto> produto = new ListaObj<>(5);

        Produto produto1 = new Produto(100,"Notebook",2000.0,"****");
        Produto produto2 = new Produto(101,"Celular",3200.0,"***");
        Produto produto3 = new Produto(102,"Tablet",2700.0,"**");
        Produto produto4 = new Produto(103,"Computador",5500.0,"***");
        Produto produto5 = new Produto(104,"Video Game",3400.0,"*****");

        produto.adicionaElemento(produto1);
        produto.adicionaElemento(produto2);
        produto.adicionaElemento(produto3);
        produto.adicionaElemento(produto4);
        produto.adicionaElemento(produto5);

        produto1.comprar(3);
        produto2.comprar(2);
        produto3.comprar(1);
        produto4.comprar(4);
        produto5.comprar(5);

        System.out.println(String.format(" %9s %-14s %7s %7s %14s \n", "CODIGO", "NOME", "PREÇO", "NOTA", "FATURAMENTO"));
      produto.exibeLista();

        gravaArquivoCsv(produto, "produto");
        leExibeArquivoCsv("produto");
    }
}
