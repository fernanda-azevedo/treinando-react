public class Patrocinador {
    private String nome;
    private String nomeEquipe;
    private Integer vitorias;
    private Double valorInvestido;

    public Patrocinador(String nome, String nomeEquipe, Integer vitorias, Double valorInvestido) {
        this.nome = nome;
        this.nomeEquipe = nomeEquipe;
        this.vitorias = vitorias;
        this.valorInvestido = valorInvestido;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("\nPATROCINADOR");
        sb.append("\nNome: '").append(nome).append('\'');
        sb.append("\nNome Equipe: '").append(nomeEquipe).append('\'');
        sb.append("\nVitórias: ").append(vitorias);
        sb.append("\nValor Investido: ").append(valorInvestido);
        sb.append("\n").append(super.toString());
        sb.append('\n');
        return sb.toString();
    }

    public Integer getPremio(){
        return (vitorias * 2 / 100) ;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeEquipe() {
        return nomeEquipe;
    }

    public void setNomeEquipe(String nomeEquipe) {
        this.nomeEquipe = nomeEquipe;
    }

    public Integer getVitorias() {
        return vitorias;
    }

    public void setVitorias(Integer vitorias) {
        this.vitorias = vitorias;
    }

    public Double getValorInvestido() {
        return valorInvestido;
    }

    public void setValorInvestido(Double valorInvestido) {
        this.valorInvestido = valorInvestido;
    }
}
