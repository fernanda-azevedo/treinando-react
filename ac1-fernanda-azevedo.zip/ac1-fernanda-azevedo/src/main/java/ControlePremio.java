import java.util.ArrayList;
import java.util.List;

public class ControlePremio {
    private List<Jogador> jogadores;

    public ControlePremio() {
        this.jogadores = new ArrayList<>();
    }

    public void adicionarJogador(Jogador j){
        jogadores.add(j);
    }

    public Double calculoTotalImposto(){
        Double totalImposto = 0.0;
        for(Jogador f: jogadores){
            totalImposto+= f.getPremio();
        }
        return totalImposto;
    }

    public void exibeJogadores(){
        for(Jogador f: jogadores){
            System.out.println(f);
        }
    }

}

