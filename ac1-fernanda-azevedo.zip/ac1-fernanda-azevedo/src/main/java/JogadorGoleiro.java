public class JogadorGoleiro extends Jogador {
    private Integer golsSofridos;
    private Integer penaltiesDefendidos;

    public JogadorGoleiro(Integer codigo, String nome, Integer nroJogos, Integer golsSofridos, Integer penaltiesDefendidos) {
        super(codigo, nome, nroJogos);
        this.golsSofridos = golsSofridos;
        this.penaltiesDefendidos = penaltiesDefendidos;
    }

    public int getDesempenho(){
        return (penaltiesDefendidos - golsSofridos) / getNroJogos();
    }

    @Override
    public int getPremio(){
        Integer desempenho = getDesempenho() * 300;
        return desempenho;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("\nGOLEIRO");
        sb.append("\n Gols Sofridos: ").append(golsSofridos);
        sb.append("\nPenalties Defendidos: ").append(penaltiesDefendidos);
        sb.append("\n").append(super.toString());
        sb.append('\n');
        return sb.toString();
    }
}
