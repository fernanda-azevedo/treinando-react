public abstract class Jogador implements Premiavel {
    private Integer codigo;
    private String nome;
    private Integer nroJogos;

    public Jogador(Integer codigo, String nome, Integer nroJogos) {
        this.codigo = codigo;
        this.nome = nome;
        this.nroJogos = nroJogos;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getNroJogos() {
        return nroJogos;
    }

    public void setNroJogos(Integer nroJogos) {
        this.nroJogos = nroJogos;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("JOGADOR");
        sb.append("\nCódigo: ").append(codigo);
        sb.append("\nNome: '").append(nome).append('\'');
        sb.append("\nNúmero de Jogos: ").append(nroJogos);
        sb.append("\n").append(super.toString());
        sb.append('\n');
        return sb.toString();
    }
}
