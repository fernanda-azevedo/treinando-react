public class JogadorAtacante extends Jogador {
    private Integer golsMarcados;
    private Integer assistencias;

    public JogadorAtacante(Integer codigo, String nome, Integer nroJogos, Integer golsMarcados, Integer assistencias) {
        super(codigo, nome, nroJogos);
        this.golsMarcados = golsMarcados;
        this.assistencias = assistencias;
    }

    public int getDesempenho(){
        return (golsMarcados + assistencias) / getNroJogos();
    }

    @Override
    public int getPremio(){
        return getDesempenho() * 200;
    }

    public Integer getGolsMarcados() {
        return golsMarcados;
    }

    public void setGolsMarcados(Integer golsMarcados) {
        this.golsMarcados = golsMarcados;
    }

    public Integer getAssistencias() {
        return assistencias;
    }

    public void setAssistencias(Integer assistencias) {
        this.assistencias = assistencias;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("\nATACANTE");
        sb.append("\nGols Marcados: ").append(golsMarcados);
        sb.append("\nAssistências: ").append(assistencias);
        sb.append("\n").append(super.toString());
        sb.append('\n');
        return sb.toString();
    }
}
