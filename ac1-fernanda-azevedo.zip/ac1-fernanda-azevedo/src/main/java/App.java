public class App {
    public static void main(String[] args) {

        JogadorAtacante ja = new JogadorAtacante(0101, "Fernanda", 5, 8, 2 );
        JogadorGoleiro jg = new JogadorGoleiro(0222, "Fernando",  10, 9, 1);

        Zagueiro zaga = new Zagueiro("Corintiano", 9);
        ControlePremio c = new ControlePremio();

        c.adicionarJogador(ja);
        c.adicionarJogador(jg);
        c.calculoTotalImposto();
        c.exibeJogadores();

        /* Adicionei uma classe extra Zagueiro para implementar a interface do método getPremio().
        * Como ela está implementando, no diagrama de classe eu coloquei a linha tracejada, e fiz o
        * cálculo do prêmio do Zagueiro ser o desempenhos dos jogadores vezes a assistencia
        * q ele deu durante o jogo (E não, zagueiro não é um jogador, portanto não coloquei relacionamento de herança)*/
    }

}
