public class Zagueiro implements Premiavel {
    private String nome;
    private Integer assistencias;

    public Zagueiro(String nome, Integer assistencias) {
        this.nome = nome;
        this.assistencias = assistencias;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("\nZAGUEIRO");
        sb.append("\nNome: '").append(nome).append('\'');
        sb.append("\nAssistências: ").append(assistencias);
        sb.append('\n');
        return sb.toString();
    }

    @Override
    public int getPremio() {
        return  getDesempenho() * assistencias;
    }

    private Integer getDesempenho() {
        return getAssistencias() ;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getAssistencias() {
        return assistencias;
    }

    public void setAssistencias(Integer assistencias) {
        this.assistencias = assistencias;
    }


}
