public interface Premiavel{
    public int getPremio();
}
