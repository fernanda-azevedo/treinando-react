public class Teste {
    public static void main(String[] args) {
        ListaObj<Produto> produto = new ListaObj<>(5);

        Produto produto1 = new Produto(100,"Notebook",2000.0,"****");
        Produto produto2 = new Produto(101,"Celular",3200.0,"***");
        Produto produto3 = new Produto(102,"Tablet",2700.0,"**");
        Produto produto4 = new Produto(103,"Computador",5500.0,"***");
        Produto produto5 = new Produto(104,"Video Game",3400.0,"*****");

        produto.adicionaElemento(produto1);
        produto.adicionaElemento(produto2);
        produto.adicionaElemento(produto3);
        produto.adicionaElemento(produto4);
        produto.adicionaElemento(produto5);

        produto1.comprar(3);
        produto2.comprar(2);
        produto3.comprar(1);
        produto4.comprar(4);
        produto5.comprar(5);

        System.out.println(String.format(" %9s %-14s %7s %7s %14s \n", "CODIGO", "NOME", "PREÇO", "NOTA", "FATURAMENTO"));
        produto.exibeLista();
    }
}
