public class Produto {
    private Integer codProduto;
    private String nome;
    private Double preco;
    private String avaliacao;
    private Integer quantidadeVendida;

    public Produto(Integer codProduto, String nomeString, Double preco, String avaliacao) {
        this.codProduto = codProduto;
        this.nome = nomeString;
        this.preco = preco;
        this.avaliacao = avaliacao;
        this.quantidadeVendida = 0;
    }

    @Override
    public String toString() {
        return String.format("%06d %-14s %7.2f %7s %14.3f \n",
                codProduto,
                nome,
                preco,
                avaliacao,
                calcularFaturamento());
    }

    public Integer comprar(Integer quantidadeComprada){
        return quantidadeVendida += quantidadeComprada;
    }

    public double calcularFaturamento(){
        return quantidadeVendida * preco;
    }

    public Integer getCodProduto() {
        return codProduto;
    }

    public void setCodProduto(Integer codProduto) {
        this.codProduto = codProduto;
    }

    public String getNomeString() {
        return nome;
    }

    public void setNomeString(String nomeString) {
        this.nome = nomeString;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    public String getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(String avaliacao) {
        this.avaliacao = avaliacao;
    }

    public Integer getQuantidadeVendida() {
        return quantidadeVendida;
    }

    public void setQuantidadeVendida(Integer quantidadeVendida) {
        this.quantidadeVendida = quantidadeVendida;
    }
}
