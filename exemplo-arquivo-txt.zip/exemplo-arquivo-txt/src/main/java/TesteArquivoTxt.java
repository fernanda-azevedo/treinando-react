import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class TesteArquivoTxt {

    public static void gravaRegistro(String registro, String nomeArq) {
        BufferedWriter saida = null;

        try {
            saida = new BufferedWriter(new FileWriter(nomeArq,true));
        }
        catch(IOException erro) {
            System.out.println("Erro na abertura do arquivo: " + erro);
        }

        try {
            saida.append(registro + "\n");
            saida.close();
        }
        catch(IOException erro) {
            System.out.println("Erro na gravação do arquivo: " + erro);
        }
    }

    public static void gravaArquivoTxt(List<Aluno> lista, String nomeArq) {
        int contaRegistroCorpo = 0;

        // Monta o registro de header
        String header = "00NOTA20221";
        header += LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));
        header += "01";
        // Grava o registro de header
        gravaRegistro(header, nomeArq);

        // Monta e grava os registros de corpo (ou de detalhe)
        String corpo;
        for (Aluno a : lista) {
            corpo = "02";
            corpo += String.format("%-5.5s", a.getCurso());
            corpo += String.format("%-8.8s", a.getRa());
            corpo += String.format("%-50.50s", a.getNome());
            corpo += String.format("%-40.40s", a.getDisciplina());
            corpo += String.format("%05.2f", a.getMedia());
            corpo += String.format("%03d", a.getQtdFalta());
            gravaRegistro(corpo, nomeArq);
            contaRegistroCorpo++;
        }

        // Monta e grava o registro de trailer
        String trailer = "01";
        trailer += String.format("%010d", contaRegistroCorpo);
        gravaRegistro(trailer, nomeArq);
    }

    public static void leArquivoTxt(String nomeArq) {
        BufferedReader entrada = null;
        String registro, tipoRegistro;
        String ra, curso, nome, disciplina;
        Double media;
        Integer qtdFalta;
        int contaRegDadoLido = 0;
        int qtdRegDadoGravado;

        List<Aluno> listaLida = new ArrayList<>();

        // Abre o arquivo para leitura
        try {
            entrada = new BufferedReader(new FileReader(nomeArq));
        }
        catch (IOException erro) {
            System.out.println("Erro na abertura do arquivo: " + erro);
        }

        // Leitura do arquivo
        try {
            // Le o primeiro registro do arquivo
            registro = entrada.readLine();

            while (registro != null) { // enquanto não for o final do arquivo
                // obtem os 2 primeiros caracteres do registro
                //  012
                //  00NOTA20221
                // Método substring recebe o índice onde começa o campo e o índice final + 1
                // Começa a contar do zero
                tipoRegistro = registro.substring(0,2);
                // Verifica se é um registro de header ("00")
                // ou se é um registro de trailer ("01")
                // ou se é um registro de corpo ("02")
                if (tipoRegistro.equals("00")) {
                    System.out.println("É um registro de header");
                    // Exibe as informações do registro de header
                    System.out.println("Tipo do arquivo: " +
                            registro.substring(2,6));
                    System.out.println("Ano e semestre: " +
                            registro.substring(6,11));
                    System.out.println("Data e hora de gravação: " +
                            registro.substring(11,30));
                    System.out.println("Versão do documento de layout: " +
                            registro.substring(30,32));
                } else if (tipoRegistro.equals("01")) {
                    System.out.println("É um registro de trailer");
                    qtdRegDadoGravado= Integer.parseInt(registro.substring(2,12));
                    if (contaRegDadoLido == qtdRegDadoGravado) {
                        System.out.println("Quantidade de registros lidos compatível " +
                                "com a quantidade de registros gravados");
                    }
                    else {
                        System.out.println("Quantidade de registros lidos incompatível " +
                                "com a quantidade de registros gravados");
                    }

                } else if (tipoRegistro.equals("02")) {
                    System.out.println("É um registro de corpo");
                    // trim() elimina os brancos à direita da String
                    curso= registro.substring(2,7).trim();
                    ra= registro.substring(7,15).trim();
                    nome= registro.substring(15,65).trim();
                    disciplina= registro.substring(65,105).trim();
                    media= Double.valueOf(registro.substring(105,110).replace(',','.'));
                    qtdFalta= Integer.valueOf(registro.substring(110,113));
                    contaRegDadoLido++;

                    // se for importar essas informações no Bco de Dados
                    // pode-se criar um obj Aluno com esses dados
                    // e fazer repository.save(obj)

                    // No nosso caso, vamos criar um objeto Aluno
                    // e adicionar esse obj para a listaLida
                    listaLida.add (new Aluno(ra,nome,curso,disciplina,media,qtdFalta));
                } else {
                    System.out.println("Tipo de registro inválido");
                }
                // Le o proximo registro
                registro = entrada.readLine();
            }
            entrada.close();
        }
        catch (IOException erro) {
            System.out.println("Erro ao ler arquivo: " + erro);
        }

        // Aqui tb seria possível fazer repository.saveAll(listaLida);
        // para salvar todo o conteúdo da lista no banco 
        System.out.println("\nLista lida do arquivo:");
        for (Aluno a : listaLida) {
            System.out.println(a);
        }
    }


    public static void main(String[] args) {
        List<Aluno> lista = new ArrayList();

        lista.add(new Aluno("01211000","Ana Silva", "ADS",
                "Estrutura de Dados", 9.0,5));
        lista.add(new Aluno("01211010","Mario Teixeira", "ADS",
                "Programação WEB", 7.5,10));
        lista.add(new Aluno("02211000","Claudete Sousa", "CCO",
                "Cálculo Computacional", 7.0,15));
        lista.add(new Aluno("04211030","José Bezerra", "REDES",
                "Segurança", 8.0,7));

        for (Aluno a : lista) {
            System.out.println(a);
        }

        gravaArquivoTxt(lista, "aluno.txt");    // se executar 2 vezes, vai duplicar os registros no arquivo
                                                         // pois está com Append=true na hora de abrir o arquivo
        leArquivoTxt("aluno.txt");

    }
}
