public class ordenacaoSort {
    public static void main(String[] args) {

    }
}
