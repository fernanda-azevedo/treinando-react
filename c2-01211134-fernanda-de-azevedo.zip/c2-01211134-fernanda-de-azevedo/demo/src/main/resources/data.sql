insert into usuario(usuario, nome, senha, autenticado)
values ( 'fernanda', 'fernandinha', '12345', false);

insert into usuario(usuario, nome, senha, autenticado)
values ( 'loginx', 'Zé Buduia Loko', 'senhay', false);

insert into usuario(usuario, nome, senha, autenticado)
values ( 'loginww', 'Maria Ruela', '4321', false);
