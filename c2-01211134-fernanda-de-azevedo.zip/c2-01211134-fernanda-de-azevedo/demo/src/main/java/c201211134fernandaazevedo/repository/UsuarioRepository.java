package c201211134fernandaazevedo.repository;

import c201211134fernandaazevedo.entity.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import javax.transaction.Transactional;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {
    Usuario findByUsuario(String usuario);
    Usuario findByUsuarioAndSenha(String usuario, String senha);

    @Transactional
    @Modifying
    @Query("update Usuario u set u.autenticado= ?2 where u.usuario = ?1")
    void setAutenticacao(String usuario, boolean autenticado);

}
