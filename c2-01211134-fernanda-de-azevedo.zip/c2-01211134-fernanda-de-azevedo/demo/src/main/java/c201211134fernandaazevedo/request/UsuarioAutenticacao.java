package c201211134fernandaazevedo.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

public class UsuarioAutenticacao {

    @NotBlank
    @Size(min = 4, max = 8)
    private String senha;

    @NotBlank
    @Size(min = 4, max = 12)
    private String usuario;

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario() {
        this.usuario = usuario;
    }
}
