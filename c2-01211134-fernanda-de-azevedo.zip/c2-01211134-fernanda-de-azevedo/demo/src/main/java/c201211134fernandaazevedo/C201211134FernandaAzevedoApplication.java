package c201211134fernandaazevedo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C201211134FernandaAzevedoApplication {

	public static void main(String[] args) {
		SpringApplication.run(C201211134FernandaAzevedoApplication.class, args);
	}

}
