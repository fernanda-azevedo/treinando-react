package c201211134fernandaazevedo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Null;
import javax.validation.constraints.Size;

//Indica qual atributo da classe será mapeado para a pk da tabela.
@Entity
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //Auto incremento
    private Integer id;

    @NotBlank
    @Size(min = 10, max = 30)
    private String nome;

    @NotBlank
    @Size(min = 4, max = 8)
    private String senha;


    @NotBlank
    @Size(min = 4, max = 12)
    private String usuario;

    private boolean autenticado;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public Integer isId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String isSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

        public boolean isAutenticado() {
            return autenticado;
        }

        public void setAutenticado(boolean autenticado) {
            this.autenticado = autenticado;
        }

}
