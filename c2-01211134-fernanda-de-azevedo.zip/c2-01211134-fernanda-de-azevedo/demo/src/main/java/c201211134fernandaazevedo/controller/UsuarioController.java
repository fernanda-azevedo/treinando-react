package c201211134fernandaazevedo.controller;

import c201211134fernandaazevedo.entity.Usuario;
import c201211134fernandaazevedo.repository.UsuarioRepository;
import c201211134fernandaazevedo.request.UsuarioAutenticacao;
import org.hibernate.mapping.UnionSubclass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {
    @Autowired
    private UsuarioRepository repository;

    //b) (2,0pt) Tenha o EndPoint POST /usuarios que recebe um JSON como este:
    @PostMapping
    public ResponseEntity cadastrarUsuario(@RequestBody @Valid Usuario novoUsuario){
        if (novoUsuario != null) {
            repository.save(novoUsuario);
            return ResponseEntity.status(201).build();
        }
        return ResponseEntity.status(400).build();
    }

    //c) (2,0pt) Tenha o EndPoint POST /usuarios/autenticacao/
    @PostMapping("/autenticacao")
    public ResponseEntity fazerLogin(@Valid @RequestBody UsuarioAutenticacao userAutenticar) {
        Usuario usuarioRepository = repository.findByUsuarioAndSenha(userAutenticar.getUsuario(), userAutenticar.getSenha());
        if (usuarioRepository == null) {
            return ResponseEntity.status(400).build();
        } else {
            if (!usuarioRepository.isAutenticado()) {
                repository.setAutenticacao(userAutenticar.getUsuario(), true);
                usuarioRepository.setAutenticado(true);
                return ResponseEntity.status(200).body(usuarioRepository);
            } else {
                return ResponseEntity.status(404).build();
            }
        }
    }

    //d) (2,0pt) Tenha o EndPoint GET /usuarios
    @GetMapping
    public ResponseEntity<List<Usuario>> getUsuarios() {
        List<Usuario> usuarios = repository.findAll();
        if (usuarios.isEmpty()) {
            return ResponseEntity.status(204).build();
        }
        return ResponseEntity.status(200).body(usuarios);
    }

    //e) (1,0pt) Tenha o EndPoint DELETE /usuarios/autenticacao/{usuario}
    @DeleteMapping("autenticacao/{usuario}")
    public ResponseEntity fazerLogoffSemDeletar(@Valid @RequestBody @PathVariable String usuario) {
        Usuario usuarioRepository = repository.findByUsuario(usuario);
        // Se o usuario NÃO existir na API, retorna status 404 e sem corpo.
        if (usuarioRepository == null) {
            return ResponseEntity.status(404).build();
        } else {
            // Se ele NÃO estiver autenticado , retorna status 406 e sem corpo.
            if (!usuarioRepository.isAutenticado()) {
                return ResponseEntity.status(406).build();
            } else {
                // Se ele estiver autenticado , retorna status 200 e sem corpo.
                repository.setAutenticacao(usuarioRepository.getUsuario(), false);
                return ResponseEntity.status(200).build();
            }
        }
    }

    //f) (1,0pt) Crie um EndPoint conforme sua criatividade que faça uso dos dados da API aqui descritos.
    //Minha intenção com esse endpoint é deletar pelo id(código), e quando dar get o usuario sumir do json.
    // Usei os Dynamic finders: existsById e deleteById
    @DeleteMapping("/{codigo}")
    public ResponseEntity deletarUsuarioPorId(@Valid @PathVariable Integer codigo) {
        if (repository.existsById(codigo)) {
            repository.deleteById(codigo);
            return ResponseEntity.status(200).build();
        }
        return ResponseEntity.status(404).build();
    }

}
