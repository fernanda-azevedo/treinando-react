import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Formatter;
import java.util.FormatterClosedException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class TesteLivro {
//Gravar o arquivo CSV a partir dessa lista.
    public static void gravarArquivoCsv(ListaObj<Livro> lista, String nomeArq){
        FileWriter arq = null;
        Formatter saida = null;
        boolean naoFuncionou = false;
        nomeArq += ".csv";

        try{
            arq = new FileWriter(nomeArq, false);
            saida = new Formatter(arq);
        } catch(IOException erro){
            System.out.println("Erro ao abrir o arquivo");
            System.exit(1);
        }

        try {
            for(int i = 0; i < lista.getTamanho(); i++){
                Livro f = lista.getElemento(i);
                saida.format("%d;%s;%s;%s;%s;%d;%.2f\n", f.getIdLivro(),f.getNome(),f.getAutor(),f.getEditora(),
                        f.getGenero(),f.getPaginas(),f.getPreco());
            }
        } catch(FormatterClosedException erro){
            System.out.println("Erro ao gravar no arquivo");
            naoFuncionou = true;
        } finally {
            saida.close();
            try{
                arq.close();
            } catch(IOException erro){
                System.out.println("Erro ao fechar o arquivo");
                naoFuncionou = true;
            }
            if(naoFuncionou){
                System.exit(1);
            }
        }
    }
//Ler o arquivo CSV e exibir de forma que os dados fiquem em colunas
    public static void leExibeArquivoCsv(String nomeArq){
        FileReader arq = null;
        Scanner entrada = null;
        boolean deuRuim = false;
        nomeArq += ".csv";

        try {
            arq = new FileReader(nomeArq);
            entrada = new Scanner(arq).useDelimiter(";|\\n");
        } catch(FileNotFoundException erro){
            System.out.println("Erro ao ler o arquivo");
            System.exit(1);
        }

        try {
            System.out.printf("%10s %-33s %-33s %-23s %-18s %7s %10s\n",
                    "ID_LIVRO","NOME","AUTOR","EDITORA", "GENERO","PAGINAS","PRECO");
            while(entrada.hasNext()){
                Integer idLivro = entrada.nextInt();
                String nome = entrada.next();
                String autor = entrada.next();
                String editora = entrada.next();
                String genero = entrada.next();
                Integer paginas = entrada.nextInt();
                Double preco = entrada.nextDouble();

                System.out.printf("%10d %-33s %-33s %-23s %-18s %7d %10.2f\n",
                        idLivro,nome,autor,editora,genero,paginas,preco);
            }
        } catch(NoSuchElementException erro){
            System.out.println("Arquivo com problemas");
            deuRuim = true;
        } catch(IllegalStateException erro){
            System.out.println("Erro na leitura do arquivo");
            deuRuim = true;
        } finally {
            entrada.close();
            try{
                arq.close();
            } catch(IOException erro){
                System.out.println("Erro ao fechar o arquivo");
                deuRuim = true;
            }
            if(deuRuim){
                System.exit(1);
            }
        }
    }

    //Atualizar o valor de um atributo de um objeto de um determinado id (atenção: é o atributo id, e não o índice).
    public static void atualizaAtributo( String nomeArq, ListaObj<Livro> lista){
        FileWriter arq = null;
        Formatter saida = null;
        Scanner entrada = null;
        boolean deuRuim = false;
        nomeArq += ".csv";

        try {
            System.out.printf("%10s \n", "Novo ID do livro");
            int idLivro = entrada.nextInt();
            int  novoIdLivro = entrada.nextInt();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }   if(deuRuim){
            System.exit(1);
        }
    }

    //adicionar um novo item à lista, num determinado índice (e não no final)
    public static void adicionaNovoItem(Integer indice, String nomeArq, ListaObj<Livro> lista) {
        FileWriter arq = null;
        Formatter saida = null;
        Scanner entrada = null;
        boolean deuRuim = false;
        nomeArq += ".csv";

        try {
            System.out.printf("%10s \n", "Novo ID do livro");

            while(true){
                lista.adiciona(indice);
                if (!entrada.hasNext())
                System.out.printf("%10d \n", indice);
                break;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }   if(deuRuim){
            System.exit(1);
        }
    }

        public static void main(String[] args) {

        ListaObj<Livro> list = new ListaObj<>(10);

        Scanner leitor = new Scanner(System.in);
        Scanner leitorLN = new Scanner(System.in);

        int digitado,idLivro;
        String nome,autor,editora,genero, nomeArq;
        int paginas;
        double preco;
        boolean fim = false;

        while(!fim) {
            System.out.println("---------------");
            System.out.println("Escolha uma opção:");
            System.out.println("1- Adiciona um livro");
            System.out.println("2- Exibir lista de livros");
            System.out.println("3- Procurar um livro da lista");
            System.out.println("4- Gravar a lista em arquivo CSV");
            System.out.println("5- Ler e exibir um arquivo CSV");
            System.out.println("6- Sair");

            digitado = leitor.nextInt();

            switch (digitado) {
                case 1:
                    System.out.println("Digite o id do livro:");
                    idLivro = leitor.nextInt();
                    System.out.println("Digite o nome do livro:");
                    nome = leitorLN.nextLine();
                    System.out.println("Digite o autor do livro:");
                    autor = leitorLN.nextLine();
                    System.out.println("Digite a editora do livro");
                    editora = leitorLN.nextLine();
                    System.out.println("Digite o gênero do livro ");
                    genero = leitorLN.nextLine();
                    System.out.println("Digite o número de páginas do livro");
                    paginas = leitor.nextInt();
                    System.out.println("Digite o preço do livro");
                    preco = leitor.nextDouble();
                    System.out.println("Digite o novo ID do livro:");
                    idLivro = leitor.nextInt();

                    list.adicionaNoIndice(new Livro(idLivro, nome, autor, editora, genero, paginas, preco));
                    break;
                case 2:
                    if (list.getTamanho() != 0) {
                        list.exibe();
                    } else {
                        System.out.println("Lista está vazia!");
                    }
                    break;

                    case 3:
                    System.out.println("Digite o ID do livro desejado");
                    idLivro = leitor.nextInt();
                    list.exibePeloIndice(idLivro);
                    break;

                case 4:
                    if(list.getTamanho() != 0){
                        System.out.println("Digite o nome do arquivo:");
                        nomeArq = leitorLN.nextLine();
                        gravarArquivoCsv(list, nomeArq);
                        list.limpa();
                    } else {
                        System.out.println("Lista está vazia não a nada a gravar!");
                    }
                    break;

                case 5:
                    System.out.println("Digite o nome do arquivo:");
                    nomeArq = leitorLN.nextLine();
                    leExibeArquivoCsv(nomeArq);
                    break;

                case 6:
                    fim = true;
                    break;

                case 7:
                    System.out.println("Digite um novo ID para o livro");
                    idLivro = leitor.nextInt();
                    list.exibePeloIndice(idLivro);

                default:
                    System.out.println("Opção invalida!");
                    break;
            }
        }
    }

}
