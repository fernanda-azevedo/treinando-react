public class Livro {
    private Integer idLivro;
    private String nome,autor,editora,genero;
    private Integer paginas;
    private Double preco;

    public Livro(Integer idLivro, String nome, String autor, String editora,
                 String genero, Integer paginas, Double preco) {
        this.idLivro = idLivro;
        this.nome = nome;
        this.autor = autor;
        this.editora = editora;
        this.genero = genero;
        this.paginas = paginas;
        this.preco = preco;
    }
    public Integer getIdLivro() {
        return idLivro;
    }

    public void setIdLivro(Integer idLivro) {
        this.idLivro = idLivro;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Integer getPaginas() {
        return paginas;
    }

    public void setPaginas(Integer paginas) {
        this.paginas = paginas;
    }

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }

    @Override
    public String toString() {
        return  "Livro " + idLivro +
                "\nTítulo: " + nome +
                "\nAutor(a): " + autor +
                "\nEditora: " + editora +
                "\nGênero: " + genero +
                "\nNº de Páginas: " + paginas +
                "\nPreço: R$" + preco+
                "\n";
    }

}
