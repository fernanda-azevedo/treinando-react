public class ListaObj<T> {

    private T[] vetor;
    private int nroElem;

    public ListaObj(int tamanho) {
        vetor = (T[]) new Object[tamanho];
        nroElem = 0;
    }

    //adicionar um novo item à lista, num determinado índice
    public int adiciona(int elementoBuscado) {
        for (int i = 0; i < nroElem; i++) {
            if (vetor[i].equals(elementoBuscado)) {
                return i;
            }
        }
        return -1;
    }

    public void adicionaNoIndice(T elemento) {
        if (nroElem >= vetor.length) {
            System.out.println("Lista está cheia");
        }
        vetor[nroElem++] = elemento;
    }

    public void exibe() {
        if (nroElem == 0) {
            System.out.println("\nA lista está vazia.");
        } else {
            System.out.println("\nElementos da lista:");
            for (int i = 0; i < nroElem; i++) {
                System.out.println(vetor[i]);
            }
            System.out.println();
        }
    }

    public T getElemento(int idLivro) {
        if (idLivro < 0 || idLivro >= nroElem) {
            return null;
        }
        return vetor[idLivro];
    }

    public void limpa() {
        nroElem = 0;
    }

    public int getTamanho() {
        return nroElem;
    }

    public void exibePeloIndice (int indice) {
        if (indice < 0 || indice >= nroElem) {
            System.out.println("\nÍndice inválido!");
        } else {
            for (int i = 0; i < nroElem; i++) {
                if (i == indice) {
                    System.out.println(vetor[i]);
                    break;
                }
                System.out.println();
            }
        }
    }

}


